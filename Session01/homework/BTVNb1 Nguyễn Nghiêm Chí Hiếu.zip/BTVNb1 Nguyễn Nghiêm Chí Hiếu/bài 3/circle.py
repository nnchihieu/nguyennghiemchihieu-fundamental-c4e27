from turtle import *
shape("turtle")
speed(0)
color("red","purple")
begin_fill()
for i in range(400):
    left(1)
    forward(2)

end_fill()
mainloop()