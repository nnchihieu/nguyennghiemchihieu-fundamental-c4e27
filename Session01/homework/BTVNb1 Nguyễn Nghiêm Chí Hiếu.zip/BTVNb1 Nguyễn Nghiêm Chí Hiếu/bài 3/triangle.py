from turtle import *
shape("turtle")
speed(1)
color("green","blue")
begin_fill()
for i in range(3):
    forward(200)
    left(120)
end_fill()
mainloop()