from turtle import *
shape("turtle")
speed(0)
color("brown")
for j in range(75):
        circle(150)
        left(5)
mainloop()
