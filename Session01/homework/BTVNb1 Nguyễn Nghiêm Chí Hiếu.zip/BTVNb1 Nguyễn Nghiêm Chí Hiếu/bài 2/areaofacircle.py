x = int(input("radius="))
v = 3.14*x*x
print("area=",v)